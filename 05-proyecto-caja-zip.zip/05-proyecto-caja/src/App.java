public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Proyecto Caja!!");

        Caja caja = new Caja(3,2,6);
        caja.seandMessage();

    }
    
}
